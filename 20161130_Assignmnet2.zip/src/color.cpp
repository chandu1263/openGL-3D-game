#include "main.h"

const color_t COLOR_RED = { 255,0,0};
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 8,0,0};
const color_t COLOR_BACKGROUND = { 242, 241, 239 };
const color_t COLOR_YELLOW = { 255, 255, 0 };
const color_t COLOR_BROWN = { 51, 0, 0 };
const color_t COlOR_WATER = {35,137,218};
const color_t COLOR_BLUE = {35,137,218};
const color_t COLOR_GREY = { 128, 128, 128 };
const color_t COLOR_LRED = { 153, 1, 1 };
const color_t COLOR_LBLUE = { 0, 255, 255 };
const color_t COLOR_ORANGE = { 255, 128, 0 };
const color_t COLOR_BOAT1 = {124, 68, 7};
const color_t COLOR_BOAT2 = {10, 12, 53};
const color_t COLOR_ROCK1 = {34, 130, 7};
const color_t COLOR_ROCK2 = {63, 21, 86};
const color_t COLOR_ROCK3 ={76, 2, 32};
const color_t COLOR_ROCK4 ={224, 4, 93};
const color_t COLOR_BOSS1={44, 39, 94};
//const color_t COlOR_BOSS2={193, 21, 156};
//const color_t COlOR_BOSS3={60, 224, 15};
