Graphics Boilerplate Code
=========================

This is boilerplate code for the assignments which might be helpful.


License
-------
The MIT License https://meghprkh.mit-license.org/

Copyright &copy; 2018 Megh Parikh <meghprkh@gmail.com>

barrels-black pyramids
* boosts
* score u have to collide with them

boat - w,a,s,d (left,right,up and down)

cannon - j and l for it's movement

c,v,b,n,m - different views

space - bomb

arrow keys for camera rotation

monsters u can kill them with bombs

boss - after u kill 5 monsters

u can easily kill him if u kill all monsters
** poisoning 

*** score
*** lives
*** health

each live = 100 health
10 lives 10 monsters
6 boosts

boost u can move fast for 5 sec


